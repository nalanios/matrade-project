package com.maitred.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class SecurityConfig {
    // Security configurations
}
