package com.maitred.services;

import org.springframework.stereotype.Service;

@Service
public class AccountService {

    // Inject repositories and perform business operations
    public boolean createCustomerAccount(Customer customer) {
        // Business logic to create customer account
    }

    public boolean createRestaurantAccount(Restaurant restaurant) {
        // Business logic to create restaurant account
    }
}
