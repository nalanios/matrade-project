package com.maitred;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MaitreDApplication {

    public static void main(String[] args) {
        SpringApplication.run(MaitreDApplication.class, args);
    }
}
